﻿// exploit

window.onload = function() {
  // setTimeout for giving the image time to load 
  setTimeout(() => {
    alert("The server got infiltrated and any javascript code could be executed on your site💀\n" +
        "Please inform the System-Admin!");
  }, 2000);
}
