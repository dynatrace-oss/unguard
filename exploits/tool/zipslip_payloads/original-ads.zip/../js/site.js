﻿// file can be overwritten with the sharpcompress path traversal exploit

window.onload = function() {
  // change the ads periodical reload
  setTimeout(() => {
    document.location.reload();
  }, 5000);
}
